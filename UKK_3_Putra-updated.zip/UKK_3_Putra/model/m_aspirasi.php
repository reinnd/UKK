<?php

include_once "m_logshanlder.php";
include_once "m_connection.php";
include_once "m_kategori.php";

class m_aspirasi
{

  protected $conn;
  protected $log_agent;
  protected $act = "manipulasi aspirasi";
  public function __construct()
  {
    $database = new m_connection();
    $this->conn = $database->conn;
    $this->log_agent = new logs_gate();
  }

  public function pagination($limit){
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    // Validasi agar page tidak negatif
    if ($page < 1) $page = 1;
    $offset = ($page - 1) * $limit;
    return "LIMIT $limit OFFSET $offset";
  }

  public function get_total_page($limit){
    $total = $this->count_all()->total_aspirasi;
    return ceil($total / $limit);
  }

  public function get_total_page_user($limit, $id_siswa){
    $total = $this->count_by_user_id($id_siswa)->total_aspirasi;
    return ceil($total / $limit);
  }

  public function get_data($limit = NULL)
  {
    $limiter = "";
    
    if(isset($limit) && $limit > 0){
      $limiter = $this->pagination($limit);
    }
    //query tabel aspirasi
    $sql = "SELECT aspirasi.*, kategori.isi_kategori, user.username, feedback.isi_feedback
            FROM aspirasi
            INNER JOIN kategori ON aspirasi.id_kategori = kategori.id_kategori
            INNER JOIN siswa ON aspirasi.id_siswa = siswa.id_siswa
            INNER JOIN user ON siswa.id_user = user.id_user
            LEFT JOIN feedback ON aspirasi.id_feedback = feedback.id_feedback
            ORDER BY aspirasi.waktu_upload DESC
            {$limiter}";
    $query = mysqli_query($this->conn, $sql);

    if ($query->num_rows > 0) {
      while ($data = mysqli_fetch_object($query)) {
        $result[] = $data;
      }
      return $result;
    } else {
      return [];
    }
  }

  public function search_and_filter_date($keywords, $start_date = null, $end_date = null, $month_year = null){
    $conditions = [];
    $base_sql = "SELECT aspirasi.*, kategori.isi_kategori, user.username, feedback.isi_feedback
            FROM aspirasi
            INNER JOIN kategori ON aspirasi.id_kategori = kategori.id_kategori
            INNER JOIN siswa ON aspirasi.id_siswa = siswa.id_siswa
            INNER JOIN user ON siswa.id_user = user.id_user
            LEFT JOIN feedback ON aspirasi.id_feedback = feedback.id_feedback";

    // Search keywords
    if (!empty($keywords)) {
        $keywords_array = array_filter(array_map('trim', preg_split('/[,\s]+/', $keywords)));
        $keyword_conditions = [];
        foreach ($keywords_array as $keyword) {
            $keyword = mysqli_real_escape_string($this->conn, $keyword);
            $keyword_conditions[] = "(aspirasi.judul LIKE '%$keyword%' OR user.username LIKE '%$keyword%' OR kategori.isi_kategori LIKE '%$keyword%' OR aspirasi.status LIKE '%$keyword%')";
        }
        $conditions[] = "(" . implode(" AND ", $keyword_conditions) . ")";
    }

    // Filter by date range
    if (!empty($start_date) && !empty($end_date)) {
        $start_date = mysqli_real_escape_string($this->conn, $start_date);
        $end_date = mysqli_real_escape_string($this->conn, $end_date);
        $conditions[] = "DATE(aspirasi.waktu_upload) BETWEEN '$start_date' AND '$end_date'";
    }

    // Filter by month and year
    if (!empty($month_year)) {
        $month_year = mysqli_real_escape_string($this->conn, $month_year);
        $conditions[] = "DATE_FORMAT(aspirasi.waktu_upload, '%Y-%m') = '$month_year'";
    }

    if (empty($conditions)) {
        return $this->get_data();
    }

    $where_clause = implode(" AND ", $conditions);
    $sql = "$base_sql 
            WHERE $where_clause
            ORDER BY aspirasi.waktu_upload DESC";
    $query = mysqli_query($this->conn, $sql);

    if ($query->num_rows > 0) {
      while ($data = mysqli_fetch_object($query)) {
        $result[] = $data;
      }
      return $result;
    } else {
      return [];
    }
  }

  public function get_data_by_id($id_aspirasi)
  {

    $sql = "SELECT aspirasi.*, kategori.isi_kategori, user.username, siswa.kelas, siswa.nama_lengkap, feedback.isi_feedback
            FROM aspirasi
            INNER JOIN kategori ON aspirasi.id_kategori = kategori.id_kategori
            INNER JOIN siswa ON aspirasi.id_siswa = siswa.id_siswa
            INNER JOIN user ON siswa.id_user = user.id_user
            
            LEFT JOIN feedback ON aspirasi.id_feedback = feedback.id_feedback
            WHERE aspirasi.id_aspirasi = $id_aspirasi";
    $query = mysqli_query($this->conn, $sql);

    if ($query->num_rows > 0) {
      return mysqli_fetch_object($query);
    } else {
      echo "ga ada data2";
    }
  }

  public function get_data_by_user_id($id_siswa, $limit = NULL)
  {
     $limiter = "";
    
    if(isset($limit) && $limit > 0){
      $limiter = $this->pagination($limit);
    }

    $sql = "SELECT aspirasi.*, kategori.isi_kategori, siswa.nama_lengkap ,user.username, feedback.isi_feedback
            FROM aspirasi
            INNER JOIN kategori ON aspirasi.id_kategori = kategori.id_kategori
            INNER JOIN siswa ON aspirasi.id_siswa = siswa.id_siswa
            INNER JOIN user ON siswa.id_user = user.id_user
            LEFT JOIN feedback ON aspirasi.id_feedback = feedback.id_feedback
            WHERE aspirasi.id_siswa = '$id_siswa'
            ORDER BY aspirasi.waktu_upload DESC
            {$limiter}";
    $query = mysqli_query($this->conn, $sql);

    if ($query->num_rows > 0) {
      while ($data = mysqli_fetch_object($query)) {
        $result[] = $data;
      }
      return $result;
    } else {
      return [];
    }
  }

  public function add_data($judul, $id_siswa, $isi_aspirasi, $id_kategori)
  {

    $kategori = new m_kategori();
    $cooked_kategori = $kategori->get_data_by_id($id_kategori)->isi_kategori;

    $sql = "INSERT INTO aspirasi (id_aspirasi, judul, id_siswa, isi_aspirasi, `status`, id_kategori, id_feedback, waktu_upload) 
            VALUES (NULL,'$judul', $id_siswa, '$isi_aspirasi', 'menunggu', $id_kategori, 1, NOW() )";
    $query = mysqli_query($this->conn, $sql);
    if ($query) {
      session_start();
      $this->log_agent->log_state(
        $_SESSION['id'],
        $_SESSION['role'],
        "$this->act",
        mysqli_insert_id($this->conn),
        "Menambah aspirasi: $judul, $isi_aspirasi, kategori: $cooked_kategori"
      );

      echo "<script>alert('data berhasil ditambah');  window.location='../view/user/u_aspirasi.php';</script>";
    } else {
      echo "<script>alert('data gagal ditambah');  window.location='../view/admin/a_form.php';</script>";
    }

  }

  public function update_data($id_aspirasi, $judul, $id_siswa, $isi_aspirasi, $id_kategori)
  {

    $old_data = $this->get_data_by_id($id_aspirasi);
    $old_judul = $old_data->judul;
    $old_isi = $old_data->isi_aspirasi;
    $old_kategori = $old_data->isi_kategori;
    $kategori = new m_kategori();
    $new_kategori = $kategori->get_data_by_id($id_kategori)->isi_kategori;

    $sql = "UPDATE `aspirasi` SET 
            `judul` = '$judul', 
            `id_siswa` = $id_siswa, 
            `isi_aspirasi` = '$isi_aspirasi',  
            `id_kategori` = $id_kategori
            WHERE `id_aspirasi` = $id_aspirasi";
    $query = mysqli_query($this->conn, $sql);

    if ($query) {
      session_start();
      $this->log_agent->log_state(
        $_SESSION['id'],
        $_SESSION['role'],
        "$this->act",
        $id_aspirasi,
        "Mengubah aspirasi: $old_judul, $old_isi, $old_kategori menjadi $judul, $isi_aspirasi, kategori: $new_kategori"
      );
      echo "<script>alert('data berhasil diupdate');  window.location='../view/user/u_aspirasi.php';</script>";
    } else {
      echo "<script>alert('data gagal diupdate');  window.location='../view/admin/a_form.php';</script>";
    }

  }

  public function delete_data($id_aspirasi)
  {

    $sql = "DELETE FROM aspirasi WHERE id_aspirasi = $id_aspirasi";
    $query = mysqli_query($this->conn, $sql);
    if ($query) {
      session_start();
      $this->log_agent->log_state(
        $_SESSION['id'],
        $_SESSION['role'],
        "$this->act",
        $id_aspirasi,
        "Menghapus aspirasi dengan id: $id_aspirasi"
      );
      echo "<script>alert('data dihapus');  window.location.href='../view/user/u_aspirasi.php';</script>";
    } else {
      echo "<script>alert('data gagal dihapus');  window.location.href='../view/user/u_aspirasi.php';</script>";
    }
  }


  //mist

  public function count_all()
  {

    $sql = "SELECT COUNT(*) AS total_aspirasi FROM aspirasi";
    $query = mysqli_query($this->conn, $sql);
    $data = mysqli_fetch_object($query);
    return $data;
  }

  public function count_by_status($status)
  {

    $sql = "SELECT COUNT(*) AS total_aspirasi FROM aspirasi WHERE `status` = '$status'";
    $query = mysqli_query($this->conn, $sql);
    $data = mysqli_fetch_object($query);
    return $data;
  }

  public function count_by_user_id($id_siswa, $status = null)
  {

    if (isset($status)) {
      $sql = "SELECT COUNT(*) AS total_aspirasi FROM aspirasi WHERE id_siswa = '$id_siswa' AND `status` = '$status'";
    } else {
      $sql = "SELECT COUNT(*) AS total_aspirasi FROM aspirasi WHERE id_siswa = '$id_siswa'";
    }

    $query = mysqli_query($this->conn, $sql);
    $data = mysqli_fetch_object($query);
    return $data;
  }


}
