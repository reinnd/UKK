<?php

include_once "m_connection.php";

abstract class m_user
{

    protected $conn;
    protected $username;
    protected $password;

    public function __construct()
    {
        $database = new m_connection();
        $this->conn = $database->conn;
    }

    public function get_data()
    {
    }

    public function get_data_by_user_id($id_user)
    {
    }

    public function login($username)
    {
    }

    public function register($username, $password_cooked, $class, $role, $fullname, $nis_nip = NULL )
    {
    }

    public function delete_data($id)
    {
    }

    protected function dupe_guard($username)
    {
        $dupe_handler = "SELECT * FROM user WHERE username = '$username'";
        $query_dupe = mysqli_query($this->conn, $dupe_handler);
        return mysqli_num_rows($query_dupe) > 0;
    }

    protected function update_user($id_user, $status = NULL){}

    protected function update_status($status){
        return "status_akun = '$status'";
    }

}

class m_admin extends m_user
{

    public function login($username)
    {
        $sql = "SELECT * FROM user WHERE username='$username'";
        $query = mysqli_query($this->conn, $sql);
        return $query;
    }

    public function register($username, $password_cooked, $class, $role, $fullname, $nis_nip = NULL)
    {
        mysqli_begin_transaction($this->conn);
        try {
            //user
            $sql = "INSERT INTO user (`id_user`, `username`, `password`, `role`, `status_akun`,  `pfp_path`, `waktu_buat`)
                    VALUES (NULL, '$username', '$password_cooked', '$role', 'nonaktif', 'default.jpg', NOW())";
            $query = mysqli_query($this->conn, $sql);
            //siswa
            $id_user = mysqli_insert_id($this->conn);
            $sql2 = "INSERT INTO admin (`id_admin`, `id_user`, `nama_lengkap`, `nip`, `bidang`)
                     VALUES (NULL, $id_user, '$fullname', NULL, '$class')"; 
            $query2 = mysqli_query($this->conn, $sql2);
            $commit = mysqli_commit($this->conn);
            if ($commit) {
                session_start();
                if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
                    echo "<script>
                            alert('Berhasil menambah admin.');
                            window.location.href = '../view/admin/a_anggota-tambah.php';
                        </script>";
                } else {
                    echo "<script>
                            alert('Registrasi Berhasil! Silakan login dengan akun baru Anda.');
                            window.location.href = '../view/index.php';
                        </script>";
                }
                return true;
            } else {
                echo "<script>
                        alert('Registrasi Gagal: Terjadi kesalahan saat menyimpan data. Silakan coba lagi.');
                        window.location.href = '../view/register.php';
                    </script>";
                return false;
            }
        } catch (Exception $e) {
            mysqli_rollback($this->conn);
            echo "error: " . $e->getMessage();
        }
    }

    public function get_data()
    {
        $sql = "SELECT * FROM admin ORDER BY waktu_buat DESC";
        $query = mysqli_query($this->conn, $sql);

        if ($query->num_rows > 0) {
            while ($data = mysqli_fetch_object($query)) {
                $result[] = $data;
            }
            return $result;
        } else {
            return [];
        }
    }

    public function get_all_data(){
        $sql = "SELECT * FROM user ORDER BY `role` ASC, waktu_buat DESC, status_akun ASC";
        $query = mysqli_query($this->conn, $sql);

        if ($query->num_rows > 0) {
            while ($data = mysqli_fetch_object($query)) {
                $result[] = $data;
            }
            return $result;
        } else {
            return [];
        }
    }

    public function search_data($keywords){
        // Pisahkan keywords dengan koma atau spasi
        $keywords_array = array_filter(array_map('trim', preg_split('/[,\s]+/', $keywords)));
        
        if (empty($keywords_array)) {
            return [];
        }

        // Build WHERE clause dengan AND logic (semua keyword harus ada)
        $where_conditions = [];
        foreach ($keywords_array as $keyword) {
            $keyword = mysqli_real_escape_string($this->conn, $keyword);
            $where_conditions[] = "(username LIKE '%$keyword%' OR role LIKE '%$keyword%' OR status_akun LIKE '%$keyword%')";
        }
        $where_clause = implode(" AND ", $where_conditions);

        $sql = "SELECT * FROM user 
                WHERE $where_clause
                ORDER BY `role` ASC, waktu_buat DESC, status_akun ASC";
        $query = mysqli_query($this->conn, $sql);

        if ($query->num_rows > 0) {
            while ($data = mysqli_fetch_object($query)) {
                $result[] = $data;
            }
            return $result;
        } else {
            return [];
        }
    }

    public function filter_by_date($start_date = null, $end_date = null, $month_year = null){
        $conditions = [];

        // Filter by date range
        if (!empty($start_date) && !empty($end_date)) {
            $start_date = mysqli_real_escape_string($this->conn, $start_date);
            $end_date = mysqli_real_escape_string($this->conn, $end_date);
            $conditions[] = "DATE(waktu_buat) BETWEEN '$start_date' AND '$end_date'";
        }

        // Filter by month and year
        if (!empty($month_year)) {
            $month_year = mysqli_real_escape_string($this->conn, $month_year);
            $conditions[] = "DATE_FORMAT(waktu_buat, '%Y-%m') = '$month_year'";
        }

        if (empty($conditions)) {
            return $this->get_all_data();
        }

        $where_clause = implode(" AND ", $conditions);
        $sql = "SELECT * FROM user 
                WHERE $where_clause
                ORDER BY `role` ASC, waktu_buat DESC, status_akun ASC";
        $query = mysqli_query($this->conn, $sql);

        if ($query->num_rows > 0) {
            while ($data = mysqli_fetch_object($query)) {
                $result[] = $data;
            }
            return $result;
        } else {
            return [];
        }
    }

    public function search_and_filter_date($keywords, $start_date = null, $end_date = null, $month_year = null){
        $conditions = [];

        // Search keywords
        if (!empty($keywords)) {
            $keywords_array = array_filter(array_map('trim', preg_split('/[,\s]+/', $keywords)));
            $keyword_conditions = [];
            foreach ($keywords_array as $keyword) {
                $keyword = mysqli_real_escape_string($this->conn, $keyword);
                $keyword_conditions[] = "(username LIKE '%$keyword%' OR role LIKE '%$keyword%' OR status_akun LIKE '%$keyword%')";
            }
            $conditions[] = "(" . implode(" AND ", $keyword_conditions) . ")";
        }

        // Filter by date range
        if (!empty($start_date) && !empty($end_date)) {
            $start_date = mysqli_real_escape_string($this->conn, $start_date);
            $end_date = mysqli_real_escape_string($this->conn, $end_date);
            $conditions[] = "DATE(waktu_buat) BETWEEN '$start_date' AND '$end_date'";
        }

        // Filter by month and year
        if (!empty($month_year)) {
            $month_year = mysqli_real_escape_string($this->conn, $month_year);
            $conditions[] = "DATE_FORMAT(waktu_buat, '%Y-%m') = '$month_year'";
        }

        if (empty($conditions)) {
            return $this->get_all_data();
        }

        $where_clause = implode(" AND ", $conditions);
        $sql = "SELECT * FROM user 
                WHERE $where_clause
                ORDER BY `role` ASC, waktu_buat DESC, status_akun ASC";
        $query = mysqli_query($this->conn, $sql);

        if ($query->num_rows > 0) {
            while ($data = mysqli_fetch_object($query)) {
                $result[] = $data;
            }
            return $result;
        } else {
            return [];
        }
    }

    public function get_all_data_by_id($id_user){
        $sql = "SELECT * FROM user WHERE id_user = $id_user";
        $query = mysqli_query($this->conn, $sql);

        $query = mysqli_query($this->conn, $sql);
        if ($query) {
            return mysqli_fetch_object($query);
        } else {
            echo "ga ada data";
        }
    }

    public function get_data_by_user_id($id_user)
    {
        $sql = "SELECT * FROM admin WHERE id_user = $id_user";
        $query = mysqli_query($this->conn, $sql);
        if ($query) {
            return mysqli_fetch_object($query);
        } else {
            echo "ga ada data";
        }
    }

    public function delete_data($id_user)
    {
        mysqli_begin_transaction($this->conn);
        try {
            $sql = "DELETE FROM admin WHERE id_user = $id_user";
            $query = mysqli_query($this->conn, $sql);

            $sql2 = "DELETE FROM user WHERE id_user = $id_user";
            $query2 = mysqli_query($this->conn, $sql2);
            
            $commit = mysqli_commit($this->conn);
            if ($commit) {
                echo "<script>alert('Data berhasil dihapus');  window.location.href='../view/admin/a_anggota.php';</script>";
            }
        } catch (Exception $e) {
            mysqli_rollback($this->conn);
            echo "<script>alert('Error: " . addslashes($e->getMessage()) . "');  window.location.href='../view/admin/a_anggota.php';</script>";
        }
    }

    public function update_user($id_user, $status = NULL){

        $by_status = "";
        if(isset($status) && $status !== NULL){
            $by_status = $this->update_status($status);
        }

        $sql = "UPDATE user SET
                {$by_status}
                WHERE id_user = $id_user";
        $query = mysqli_query($this->conn, $sql);
        if ($query) {
            echo "<script>alert('Status berhasil diupdate');  window.location.href='../view/admin/a_anggota-detail.php?id=$id_user';</script>";
        } else {
            echo "<script>alert('Status gagal diupdate');  window.location.href='../view/admin/a_anggota-detail.php?id=$id_user';</script>";
        }
    }

    public function update_data($id_user, $username, $nama_lengkap, $profile_field, $profile_value, $role) {
        mysqli_begin_transaction($this->conn);
        try {
            // Update user table
            $username = mysqli_real_escape_string($this->conn, $username);
            $sql_user = "UPDATE user SET username = '$username' WHERE id_user = $id_user";
            $query_user = mysqli_query($this->conn, $sql_user);

            // Update profile table based on role
            if ($role === 'admin') {
                $nama_lengkap = mysqli_real_escape_string($this->conn, $nama_lengkap);
                $profile_value = mysqli_real_escape_string($this->conn, $profile_value);
                $sql_profile = "UPDATE admin SET nama_lengkap = '$nama_lengkap', $profile_field = '$profile_value' WHERE id_user = $id_user";
            } else {
                $nama_lengkap = mysqli_real_escape_string($this->conn, $nama_lengkap);
                $kelas = mysqli_real_escape_string($this->conn, $profile_value); // kelas is combined
                $sql_profile = "UPDATE siswa SET nama_lengkap = '$nama_lengkap', kelas = '$kelas' WHERE id_user = $id_user";
            }
            $query_profile = mysqli_query($this->conn, $sql_profile);

            $commit = mysqli_commit($this->conn);
            if ($commit && $query_user && $query_profile) {
                echo "<script>alert('Data berhasil diupdate'); window.location.href='../view/admin/a_anggota-detail.php?id=$id_user';</script>";
            } else {
                throw new Exception('Update failed');
            }
        } catch (Exception $e) {
            mysqli_rollback($this->conn);
            echo "<script>alert('Error: " . addslashes($e->getMessage()) . "'); window.location.href='../view/admin/a_anggota-detail.php?id=$id_user';</script>";
        }
    }
}

class m_siswa extends m_user
{

    public function login($username)
    {
        $sql = "SELECT * FROM siswa WHERE username='$username'";
        $query = mysqli_query($this->conn, $sql);
        return $query;
    }

    public function get_data()
    {
        $sql = "SELECT * FROM siswa ORDER BY waktu_buat DESC";
        $query = mysqli_query($this->conn, $sql);

        if ($query->num_rows > 0) {
            while ($data = mysqli_fetch_object($query)) {
                $result[] = $data;
            }
            return $result;
        } else {
            echo "ga ada data";
        }
    }

    public function get_data_by_user_id($id_user)
    {
        $sql = "SELECT * FROM siswa WHERE id_user = $id_user";
        $query = mysqli_query($this->conn, $sql);
        if ($query) {
            return mysqli_fetch_object($query);
        } else {
            echo "ga ada data";
        }
    }

    public function register($username, $password_cooked, $class, $role, $fullname, $nis_nip = NULL)
    {
        if($this->dupe_guard($username)){
            header("location: ../view/register.php?err=dupe&usr=$username&class=$class&flname=$fullname");
            exit();
        }

        mysqli_begin_transaction($this->conn);
        try {
            //user
            $sql = "INSERT INTO user (`id_user`, `username`, `password`, `role`, `status_akun`, `pfp_path`, `waktu_buat`)
                    VALUES (NULL, '$username', '$password_cooked', '$role', 'nonaktif','default.jpg', NOW())";
            $query = mysqli_query($this->conn, $sql);
            //siswa
            $id_user = mysqli_insert_id($this->conn);
            $sql2 = "INSERT INTO siswa (`id_siswa`, `id_user`, `nama_lengkap`, `kelas`, `nis`)
                     VALUES (NULL, $id_user, '$fullname', '$class', NULL)";
            $query2 = mysqli_query($this->conn, $sql2);
            $commit = mysqli_commit($this->conn);
            if ($commit) {
            session_start();
                if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
                    echo "<script>
                            alert('Berhasil menambah siswa.');
                            window.location.href = '../view/admin/a_anggota-tambah.php';
                        </script>";
                } else {
                    echo "<script>
                            alert('Registrasi Berhasil! Silakan login dengan akun baru Anda.');
                            window.location.href = '../view/index.php';
                        </script>";
                }
                return true;
            } else {
                echo "<script>
                        alert('Registrasi Gagal: Terjadi kesalahan saat menyimpan data. Silakan coba lagi.');
                        window.location.href = '../view/register.php';
                    </script>";
                return false;
            }
        } catch (Exception $e) {
            mysqli_rollback($this->conn);
            echo "error: " . $e->getMessage();
        }
    }

    public function delete_data($id_user)
    {
        
        mysqli_begin_transaction($this->conn);
        try {
           
            $sql = "DELETE FROM siswa WHERE id_user = $id_user";
            $query = mysqli_query($this->conn, $sql);
            
            $sql2 = "DELETE FROM user WHERE id_user = $id_user";
            $query2 = mysqli_query($this->conn, $sql2);
            
            $commit = mysqli_commit($this->conn);
            if ($commit) {
                echo "<script>alert('Data berhasil dihapus');  window.location.href='../view/admin/a_anggota.php';</script>";
            }
        } catch (Exception $e) {
            mysqli_rollback($this->conn);
            echo "<script>alert('Error: " . addslashes($e->getMessage()) . "');  window.location.href='../view/admin/a_anggota.php';</script>";
        }
    }


}

?>