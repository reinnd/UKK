<?php

include_once __DIR__ . "../../model/m_user.php";

$admin = new m_admin();
$siswa = new m_siswa();

try {
    if (!empty($_GET['action'])) {

        if ($_GET['action'] != "delete") {

            if ($_GET['action'] == "login") {

                $username = $_POST['username'];
                $password = $_POST['password'];

                $result = $admin->login($username);

                if ($result && $result->num_rows > 0) {
                    $data = $result->fetch_object();
                    if (password_verify($password, $data->password)) {
                        session_start();
                        $_SESSION['login'] = true;
                        $_SESSION['id'] = $data->id_user;
                        $_SESSION['user'] = $data->username;
                        $_SESSION['role'] = $data->role;
                        $_SESSION['stat'] = $data->status_akun;

                        if(isset($_SESSION['stat']) && $_SESSION['stat'] === 'banned'){

                        } elseif(isset($_SESSION['stat']) && $_SESSION['stat'] === 'nonaktif') {
                            session_unset();
                            session_destroy();
                            echo "<script>
                                alert('AKUN NONAKTIF.');
                                window.location.href = '../view/index.php';
                                </script>";
                        } else {
                            if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
                                $admin_result = $admin->get_data_by_user_id($_SESSION['id']);
                                $_SESSION['id_role'] = $admin_result->id_admin;
                                $_SESSION['flname'] = $admin_result->nama_lengkap;
                                header("Location: ../view/admin/a_dashboard.php");
                                exit();
                            }

                            if (isset($_SESSION['role']) && $_SESSION['role'] === 'siswa') {
                                $siswa_result = $siswa->get_data_by_user_id($_SESSION['id']);
                                $_SESSION['id_role'] = $siswa_result->id_siswa;
                                $_SESSION['flname'] = $siswa_result->nama_lengkap;
                                header("Location: ../view/user/u_dashboard.php");
                                exit();
                            }
                        }
                    }
                } 
                echo "<script>
                    alert('Login Gagal! Pastikan username dan password benar.');
                    window.location.href = '../view/index.php';
                    </script>";

            } elseif ($_GET['action'] == "register") {
                $username = $_POST['username'];
                $password_raw = $_POST['password'];
                $password_cooked = password_hash($password_raw, PASSWORD_DEFAULT);
                $fullname = $_POST['flname'];
                $role = $_POST['role'] ?? (isset($_GET['type']) && $_GET['type'] == 'primary' ? 'admin' : $role);
                $nis_nip = $_POST['nis'] ?? $_POST['nip'] ?? null;

                if ($role === 'siswa') {
                    $kelas = trim($_POST['kelas'] . ' ' . $_POST['jurusan'] . ' ' . $_POST['subkelas']);
                    $siswa->register($username, $password_cooked, $kelas, $role, $fullname, $nis_nip);
                } else if ($role === 'admin') {
                    $bidang = $_POST['bidang'];
                    $admin->register($username, $password_cooked, $bidang, $role, $fullname, $nis_nip);
                } else {
                    echo "<script>alert('Role tidak valid'); history.back();</script>";
                }
            } elseif ($_GET['action'] == 'logout') {
                // c - wifcat
                session_start(); // restart
                session_unset(); // Kosongkan semua variabel session
                session_destroy(); // Hancurkan session-nya
                header("Cache-Control: no-cache, must-revalidate");
                header("Location: ../index.php");
                exit;
            } elseif($_GET['action'] == 'add'){
                if($_GET['type'] == 'primary'){

                }
            } else {

                if($_GET['action'] == 'update'){
                    
                    if ($_GET['type'] == 'status') {
                        $status = $_POST['status'];
                        $id_user = $_POST['id_user'];

                        $admin->update_user($id_user, $status);
                    } elseif ($_GET['type'] == 'bann'){
                        $status = 'banned';
                        $id_user = $_GET['id_user'];
                        
                        $admin->update_user($id_user, $status);
                    } elseif ($_GET['type'] == 'data'){
                        $id_user = $_POST['id_user'];
                        $username = $_POST['username'];
                        $nama_lengkap = $_POST['flname'];
                        $role = $_GET['role'];
                        
                        // Update user table first
                        $username = mysqli_real_escape_string($this->conn, $username);
                        $sql_user = "UPDATE user SET username = '$username' WHERE id_user = $id_user";
                        mysqli_query($this->conn, $sql_user);
                        
                        // Update profile
                        if ($role === 'admin') {
                            $nama_lengkap = mysqli_real_escape_string($this->conn, $nama_lengkap);
                            $bidang = mysqli_real_escape_string($this->conn, $_POST['bidang'] ?? '');
                            $nip = mysqli_real_escape_string($this->conn, $_POST['nip'] ?? '');
                            $sql = "UPDATE admin SET nama_lengkap = '$nama_lengkap', bidang = '$bidang', nip = '$nip' WHERE id_user = $id_user";
                        } else {
                            $nama_lengkap = mysqli_real_escape_string($this->conn, $nama_lengkap);
                            $kelas = mysqli_real_escape_string($this->conn, trim($_POST['kelas'] . ' ' . $_POST['jurusan'] . ' ' . $_POST['subkelas']));
                            $nis = mysqli_real_escape_string($this->conn, $_POST['nip'] ?? '');
                            $sql = "UPDATE siswa SET nama_lengkap = '$nama_lengkap', kelas = '$kelas', nis = '$nis' WHERE id_user = $id_user";
                        }
                        $query = mysqli_query($this->conn, $sql);
                        if ($query) {
                            echo "<script>alert('Data berhasil diupdate'); window.location.href='../view/admin/a_anggota-detail.php?id=$id_user';</script>";
                        } else {
                            echo "<script>alert('Update gagal: " . mysqli_error($this->conn) . "'); window.location.href='../view/admin/a_anggota-detail.php?id=$id_user';</script>";
                        }
                    }
                }
            }
        } else {
            $id_user = $_GET['id_user'];
            $role = $_GET['role'];
            if ($role === 'admin') {
                $admin->delete_data($id_user);
            } else {
                $siswa->delete_data($id_user);
            }
        
        }
    } else {
        $search_keyword = isset($_GET['search']) && !empty($_GET['search']) ? $_GET['search'] : null;
        $start_date = isset($_GET['start_date']) && !empty($_GET['start_date']) ? $_GET['start_date'] : null;
        $end_date = isset($_GET['end_date']) && !empty($_GET['end_date']) ? $_GET['end_date'] : null;
        $month_year = isset($_GET['month']) && !empty($_GET['month']) ? $_GET['month'] : null;

        // Determine which filtering method to use
        if (!empty($search_keyword) || !empty($start_date) || !empty($end_date) || !empty($month_year)) {
            $get_all = $admin->search_and_filter_date($search_keyword, $start_date, $end_date, $month_year);
        } else {
            $get_all = $admin->get_all_data();
        }
        $get_siswa = $siswa->get_data();
        $get_alal = array_merge();
    }
} catch (Exception $e) {
    $e->getMessage();
}

?>