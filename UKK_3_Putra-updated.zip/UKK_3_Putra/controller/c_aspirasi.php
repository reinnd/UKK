<?php

include_once __DIR__ . "../../model/m_aspirasi.php";

$aspirasi = new m_aspirasi();

try {
  //cek apakah minta aksi
  if (!empty($_GET['action'])) {

    //cek apakah << T I D A K >> minta delete
    if ($_GET['action'] != 'delete') {

      // $id_aspirasi   = $_POST['id_aspirasi'];
      $judul = $_POST['judul'];
      $id_siswa = $_POST['id_siswa'];
      $isi_aspirasi = $_POST['isi_aspirasi'];
      $id_kategori = $_POST['kategori'];

      if ($_GET['action'] == 'add') {
        $aspirasi->add_data($judul, $id_siswa, $isi_aspirasi, $id_kategori);

      } elseif ($_GET['action'] == 'update') {
        $id_aspirasi = $_POST['id_aspirasi'];
        $aspirasi->update_data($id_aspirasi, $judul, $id_siswa, $isi_aspirasi, $id_kategori);
      }
    } else {
      $id_aspirasi = $_GET['id'];
      $aspirasi->delete_data($id_aspirasi);
    }
  } else {
        $search_keyword = isset($_GET['search']) && !empty($_GET['search']) ? $_GET['search'] : null;
        $start_date = isset($_GET['start_date']) && !empty($_GET['start_date']) ? $_GET['start_date'] : null;
        $end_date = isset($_GET['end_date']) && !empty($_GET['end_date']) ? $_GET['end_date'] : null;
        $month_year = isset($_GET['month']) && !empty($_GET['month']) ? $_GET['month'] : null;

        // Determine which filtering method to use
        if (!empty($search_keyword) || !empty($start_date) || !empty($end_date) || !empty($month_year)) {
            $data = $aspirasi->search_and_filter_date($search_keyword, $start_date, $end_date, $month_year);
        } else {
            $data = $aspirasi->get_data();
        }
  }
} catch (Exception $e) {
  echo $e->getMessage();
}
?>