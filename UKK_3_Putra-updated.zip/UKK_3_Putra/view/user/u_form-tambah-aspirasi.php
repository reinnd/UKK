<?php
    include_once "../../controller/c_auth.php";

    use App\c_auth\guard;
    guard::notlogedin();
    include_once "../../controller/c_kategori.php";
    $active_page = 'aspirasi';
    
    //head
    include("../html/header.php");
?>
    <title>Tulis Aspirasimu</title>
</head>
<body>
    <!-- header & navigation -->
<?php
    include("../html/navbar.php");
?>
<!-- main start here -->
        <section class="container form-container">
            <div class="flex">
                <h4>Sampaikan Aspirasimu</h4>
                <div>
                    <a class="back" href="u_aspirasi.php">
                    <i class="fa-solid fa-arrow-turn-down fa-rotate-90"></i>
                    Kembali
                </a>
                </div>
                
            </div>
            
            
            <form action="../../controller/c_aspirasi.php?action=add" method="POST">
                <div class="form-group flex">
                    <label for="judul">Topik</label>
                    <input type="text" id="judul" name="judul" class="input-container" maxlength="50" placeholder="Contoh: Kerusakan Fasilitas" required>
                </div>

                <div class="form-group flex">
                    <label for="kategori">Kategori</label>
                    <select id="kategori" name="kategori" class="input-container" required>
                        <option value="" disabled selected>Pilih kategori..</option>
                <?php 
                    foreach($all_kategori as $result){
                ?>
                        <option value="<?= $result->id_kategori ?>"><?= $result->isi_kategori; ?></option>
                <?php } ?>
                    </select>
                </div>

                <div class="form-group flex">
                    <label for="isi_aspirasi">Tulis aspirasimu</label>
                    <textarea id="isi_aspirasi" name="isi_aspirasi" class="input-container" placeholder="Ceritakan detail aspirasi atau keluhanmu di sini..." required></textarea>
                </div>

                <input type="number" id="id_siswa" name="id_siswa" value="<?= $_SESSION['id_role'] ?>" class="input-container" hidden>

                <button type="submit" class="btn-form">Kirim Aspirasi</button>
            </form>
        </section>
<!-- footer & closing -->
<?php
    include("../html/footer.php");
?>