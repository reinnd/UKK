<?php
include_once "../../controller/c_auth.php";

use App\c_auth\guard;
guard::notlogedin();
include_once "../../controller/c_aspirasi.php";
$db = new m_aspirasi();

$limit = 10;
$user_data = $db->get_data_by_user_id($_SESSION['id_role'], $limit);
$total_page = $db->get_total_page_user($limit,$_SESSION['id_role']);
$active_page = 'aspirasi';
//head
include("../html/header.php");
?>
<script src="../asset/js/statsHandler.js"></script>
<title>Aspirasi</title>
</head>

<body>
    <!-- header & navigation -->
    <?php
    include("../html/navbar.php");
    ?>
    <!-- main start here -->
    <section class="container">
        <a href=" u_form-tambah-aspirasi.php">
            <div class="btn-form">Tambah Aspirasi Baru <i class="fa-solid fa-plus"></i>
            </div>
        </a>
    </section>
    <section class="container">
        <div class="overflow-x flex">
            <table class="flex-grow">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Dari</th>
                        <th>Tentang</th>
                        <th>Kategori</th>
                        <th>Waktu Upload</th>
                        <th>status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    if (!empty($user_data)) {
                        foreach ($user_data as $result) {
                            ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $result->username ?></td>
                                <td><?= $result->judul ?></td>
                                <td><?= $result->isi_kategori ?></td>
                                <td><?= date('d M Y', strtotime($result->waktu_upload)) ?></td>
                                <?php 
                                    $stats = $result->status;
                                    if ($stats === 'menunggu') { ?>
                                        <td><i class="menunggu-style"><?= $stats ?></i></td>
                                <?php } else if ($stats === 'proses') { ?>
                                    <td><i class="proses-style"><?= $stats ?></i></td>
                                <?php } else if ($stats === 'selesai') { ?>
                                    <td><i class="selesai-style"><?= $stats ?></i></td>
                                <?php } else { ?>
                                    <td><i class="error-style"><?= $stats ?></i></td>
                                <?php } ?>
                                
                                <td>
                                    <?php
                                    if ($result->status !== "menunggu") {
                                        ?>
                                        <div class="flex table-btn-container">
                                        <a href="u_lihat-balasan.php?&id=<?= $result->id_aspirasi ?>" id="edt" class="edit">Lihat detail</a>
                                        </div>
                                    <?php } else { ?>
                                    <div class="flex table-btn-container">
                                        <a href="u_lihat-balasan.php?&id=<?= $result->id_aspirasi ?>" id="edt" class="edit">Lihat detail</a>
                                        <div class="flex">
                                            <a href="u_form-edit-aspirasi.php?&id=<?= $result->id_aspirasi ?>" id="edt"
                                            class="edit flex-grow">edit</a>
                                        <a href="../../controller/c_aspirasi.php?action=delete&id=<?= $result->id_aspirasi ?>"
                                            id="del" class="delete flex-grow">hapus</a>
                                        </div>
                                    </div>
                                        
                                    <?php } ?>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        echo '<tr><td colspan="9" style="text-align: center;">Belum ada aspirasi</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <?php if($total_page > 0){ 
                    $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
                    if ($current_page < 1) $current_page = 1;
                    if ($current_page > $total_page) $current_page = $total_page;
                ?>
                    <ul class="pagination">
                        <li><a href="?page=<?= max(1, $current_page - 1) ?>" 
                               class="<?= ($current_page <= 1) ? 'disabled' : '' ?>">&laquo;</a></li>
                        <li><a href="?" class="<?= $current_page == 1 ? 'active' : '' ?>">1</a></li>
                        <?php 
                            for($i = 2; $i <= $total_page; $i++) {
                                $active = ($i == $current_page) ? 'active' : '';
                        ?>
                            <li><a href="?page=<?= $i ?>" class="<?= $active ?>"><?= $i ?></a></li>
                        <?php } ?>
                        <li><a href="?page=<?= min($total_page, $current_page + 1) ?>" 
                               class="<?= ($current_page >= $total_page) ? 'disabled' : '' ?>">&raquo;</a></li>
                    </ul>
                <?php } ?>
    </section>
    <!-- footer & closing -->
    <?php
    include("../html/footer.php");
    ?>