<?php
include_once "../../controller/c_auth.php";

use App\c_auth\guard;
guard::notlogedin();
include_once "../../controller/c_aspirasi.php";
$db = new m_aspirasi();
$user_data = $db->get_data_by_id($_GET['id']);

include_once "../../controller/c_kategori.php";
$active_page = 'aspirasi';
//head
include("../html/header.php");
?>
<title>Edit aspirasi</title>
</head>

<body>
    <!-- header & navigation -->
    <?php
    include("../html/navbar.php");
    ?>
    <!-- main start here -->
    <section class="container" style="display: block; max-width: 800px; margin-left: auto; margin-right: auto;">
            <div class="flex">
                <h4>Edit Aspirasi</h4>
                <div>
                    <a class="back" href="u_aspirasi.php">
                    <i class="fa-solid fa-arrow-turn-down fa-rotate-90"></i>
                    Kembali
                </a>
                </div>
                
            </div>

        <form action="../../controller/c_aspirasi.php?action=update" method="POST">
            <?php

            ?>
            <div class="form-group flex">
                <label for="judul">Topik</label>
                <input type="text" value="<?= $user_data->judul ?>" id="judul" name="judul" class="input-container"
                    placeholder="Contoh: Kerusakan Fasilitas" maxlength="50" required>
            </div>

            <div class="form-group flex">
                <label for="kategori">Kategori</label>
                <select id="kategori" name="kategori" class="input-container" required>
                    </option>
                    <?php
                    foreach ($all_kategori as $result) {
                        ?>
                        <option value="<?= $result->id_kategori ?>" <?= $user_data->id_kategori == $result->id_kategori ? 'selected' : '' ?>><?= $result->isi_kategori; ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group flex">
                <label for="isi_aspirasi">Tulis aspirasimu</label>
                <textarea id="isi_aspirasi" value="<?= $user_data->isi_aspirasi ?>" name="isi_aspirasi"
                    class="input-container" placeholder="Ceritakan detail aspirasi atau keluhanmu di sini..."
                    required><?= $user_data->isi_aspirasi ?></textarea>
            </div>

            <input type="number" id="id_siswa" name="id_siswa" value="<?= $_SESSION['id_role'] ?>" class="input-container"
                hidden>
            <input type="number" id="id_aspirasi" name="id_aspirasi" value="<?= $_GET['id'] ?>" class="input-container"
                hidden>

            <?php ?>

            <button type="submit" class="btn-form">Kirim Aspirasi</button>
        </form>
    </section>
    <!-- footer & closing -->
    <?php
    include("../html/footer.php");
    ?>