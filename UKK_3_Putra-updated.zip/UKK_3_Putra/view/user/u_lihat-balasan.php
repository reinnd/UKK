<?php
include_once "../../controller/c_auth.php";

use App\c_auth\guard;
guard::notlogedin();

include_once "../../model/m_aspirasi.php";
$db = new m_aspirasi();
$data_aspirasi = $db->get_data_by_id($_GET['id']);

include_once "../../model/m_feedback.php";
$db2 = new m_feedback();
$data_feedback = $db2->get_feedback_by_aspirasi($data_aspirasi->id_feedback);
//head
$active_page = 'aspirasi';
include "../html/header.php";
?>
<link rel="stylesheet" href="../asset/style/form.css?v=2">
<title>Feedback</title>
</head>

<body>
    <!-- header & navigation -->
    <?php
    include "../html/navbar.php";
    ?>
    <!-- main start here -->

    <section class="container form-container overflow-x">
        <h4>Lihat Balasan</h4>

            <div class="text-group flex ">
                <div>
                    <div class="text-container"><b>Dari:</b><?= ' ' . $data_aspirasi->username ?></div>
                    <div class="text-container"><b>Nama lengkap:</b><?= ' ' . $data_aspirasi->nama_lengkap ?></div>
                    <div class="text-container"><b>Kelas:</b><?= ' ' . $data_aspirasi->kelas ?></div>
                </div>
                
                <div class=""><b><?= date("d F Y", strtotime($data_aspirasi->waktu_upload)) ?></b></div>
            </div>

            <div class="form-group flex">
                <div for="judul">Topik</div>
                <div class="input-container"><?= $data_aspirasi->judul ?></div>
            </div>
            
            <div class="form-group flex">
                <div for="judul">Kategori</div>
                <div class="input-container"><?= $data_aspirasi->isi_kategori ?></div>
            </div>

            <div class="form-group flex">
                <div>Detail</div>
                <div class="input-container"><?= $data_aspirasi->isi_aspirasi ?>
                </div>
            </div>

            <input type="number" id="id_siswa" name="id_siswa" value="<?= $_SESSION['id'] ?>" class="input-container"
                hidden>
            <?php
                if($data_aspirasi->status === 'proses' || $data_aspirasi->status === 'selesai'){
            ?>
            <div class="form-group flex" id="feed-prosc">
                <p style="font-size: 1.2em;">Diproses oleh: <b><?= $data_feedback->username1 ?></b></p>
                <p>Balasan admin</p>
                <div class="input-container"><?= $data_feedback->isi_feedback ?>
                </div>
                <small><?= date("d-F-y, H:i",strtotime($data_feedback->waktu_upload)) ?></small>
            </div>
            <?php } ?>
            <?php
                if($data_aspirasi->status === 'selesai'){
            ?>
            <div class="form-group flex" id="feed-done">
                <p style="font-size: 1.2em;">Diselesaikan oleh: <b><?= $data_feedback->username2 ?></b></p>
                <p>Balasan admin</p>
                <div  class="input-container"><?= $data_feedback->isi_feedback2 ?>
                </div>
                <small><?= date("d-F-y, H:i",strtotime($data_feedback->waktu_update)) ?></small>
            </div>
            <?php } ?>

            <div class="form-group flex">
                <p>Status</p>
                <div  class="input-container"><?= $data_aspirasi->status ?>
                </div>
            </div>
            <a class="btn-form" href="u_aspirasi.php">Kembali</a>
    </section>
    <script>
        const fedDone = document.getElementById('feed-done');
        const fedPrc = document.getElementById('feed-prosc');

        if(statBefore.value === 'selesai'){
            fedVal.hidden = true;
            fedLbl.style.display = 'none';
            fedPrc.style.display = "block";
        } else if(statBefore.value === 'proses'){
            fedDone.style.display = "none";
        } else if(statBefore.value === 'menunggu') {
            fedDone.style.display = "none";
            fedPrc.style.display = "none";
        }
    </script>
    <!-- footer & closing -->
    <?php
    include "../html/footer.php";
    ?>