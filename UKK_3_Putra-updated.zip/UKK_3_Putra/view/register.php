<?php

// include_once("../controller/c_user.php");

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="asset/style/font.css">
    <link rel="stylesheet" href="asset/style/prop.css?v=3.2">
    <link rel="stylesheet" href="asset/style/header.css?v=3">
    <link rel="stylesheet" href="asset/style/style.css?v=3">
    <link rel="stylesheet" href="asset/style/frontpage.css?v=1.2">
    <link rel="stylesheet" href="asset/font/fontawesome/css/all.css">
    <script src="asset/js/frontpageHandler.js?v=1"></script>
    <script src="asset/js/allClass.js?v=1"></script>
</head>

<body>

    <div class="frontpage-card">
        <h2>Buat Akun</h2>

        <form id="form-register" action="../controller/c_user.php?action=register" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" maxlength="50" class="input-container" required>
                <p class="" style="display: none;" id="user-alert">Username sudah dipakai, coba yang lain</p>
            </div>

            <div class="form-group">
                <label for="fullname">Nama lengkap</label>
                <input type="text" id="fullname" name="fullname" class="input-container" maxlength="50">
            </div>

            <div class="form-group">
                <label for="kelas">Kelas: </label>
                <div class="flex">
                    <select name="kelas" id="subject" class="input-container">
                        <option value="" disabled selected>Pilih Kelas</option>
                    </select>
                    <select name="jurusan" id="topic" class="input-container">
                        <option value="" disabled selected>Pilih Jurusan</option>
                    </select>
                    <select name="subkelas" id="chapter" class="input-container">
                        <option value="" disabled selected>Pilih Subkelas</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="flex input-container2" id="pw_holder">
                    <input type="password" id="password" name="password" class="form-password" required>
                    <span class="flex password-eye" id="pwSwitch"><i id="pw_eye"
                            class="fa-solid fa-eye-slash"></i></span>
                </div>
                <p style="display:none;" id="pw-alert">Password minimal 8 karakter</p>
            </div>

            <input type="text" value="siswa" name="role" hidden>

            <button type="submit" class="frontpage-button">DAFTAR</button>
        </form>

        <div class="switch-gate">
            Sudah punya akun? <a href="index.php">Login di sini</a>
        </div>
    </div>

</body>

</html>