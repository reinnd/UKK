document.addEventListener('DOMContentLoaded', function() {
    const statsElements = document.querySelectorAll('.stat');
    statsElements.forEach(function(statsType) {
        if(statsType.value === 'menunggu'){
            statsType.style.color = '#f0ad4e';
        } else if(statsType.value === 'proses'){
            statsType.style.color = '#5bc0de';
        } else if(statsType.value === 'selesai'){
            statsType.style.color = '#5cb85c';
        }
        console.log(statsType.value);
    });
    console.log('Stats handler applied to all rows');
});
