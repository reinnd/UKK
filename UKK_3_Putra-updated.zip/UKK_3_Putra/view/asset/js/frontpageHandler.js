const urlParam = new URLSearchParams(window.location.search);

document.addEventListener('DOMContentLoaded', function () {
    const pwBtn = document.getElementById('pwSwitch');
    const thePw = document.getElementById('password');
    const pwEye = document.getElementById('pw_eye');
    const pwHolder = document.getElementById('pw_holder');
    const pwAlert = document.getElementById('pw-alert');
    
    if (pwBtn && thePw && pwEye && pwHolder) {
        pwBtn.addEventListener('click', function () {
            if (thePw.type === 'password') {
                thePw.type = 'text';
                pwEye.classList.remove('fa-eye-slash');
                pwEye.classList.add('fa-eye')

            } else {
                thePw.type = 'password';
                pwEye.classList.remove('fa-eye');
                pwEye.classList.add('fa-eye-slash')
            }
        });

        thePw.addEventListener('focus', function () {
            pwHolder.classList.add('input-container2-focus');
        });

        thePw.addEventListener('blur', function () {
            pwHolder.classList.remove('input-container2-focus');
        });
    }
    console.log('pw eye swither enabled');

    thePw.onkeyup = function () {
        //pw min 8
        if(thePw.value.length >= 8){
            pwAlert.style.display = "none";
        } else {
            pwAlert.style.display = "block";
        }
    }
    const regForm = document.getElementById('form-register');
    if(regForm){
        regForm.addEventListener('submit', function(e){
            if(thePw.value.length < 8){
                e.preventDefault();
                thePw.focus();
            }
        })
        console.log('regis form detected');
    }

    if(urlParam.get('err') == 'dupe') {
    console.log('Duplicate data');

    const userAlert = document.getElementById('user-alert');
    const userField = document.getElementById('username');
    const flnameField = document.getElementById('fullname');
    const classField = document.getElementById('kelas');

    userAlert.style.display = "block";
    userField.style.borderColor = "red";
    userField.value = urlParam.get('usr');
    flnameField.value = urlParam.get('flname');
    classField.value = urlParam.get('class');

    userField.addEventListener('click',function(){
        userAlert.style.display = "none";
        userField.style.borderColor = "";
    });
    
    window.history.replaceState({}, document.title, window.location.pathname);
}
   
});