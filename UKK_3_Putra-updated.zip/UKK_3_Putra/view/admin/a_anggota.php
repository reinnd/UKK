<?php
    include_once "../../controller/c_auth.php";

    use App\c_auth\guard;
    guard::soadmin();
    
    include_once "../../controller/c_user.php";
    //head
    $active_page = 'anggota';
    include "../html/header.php";
?>
    <title>Dashboard</title>
</head>
<body>
    <!-- header & navigation -->
<?php
    include "../html/navbar.php";
?>
<!-- main start here -->
        <section class="container">
            <a href="a_anggota-tambah.php?type=secondary">
                <div class="btn-form">Tambah Anggota <i class="fa-solid fa-plus"></i></div>
            </a>
        </section>
        <section class="container">
                <form method="GET" id="searchForm" style="display: flex; gap: 1rem; align-items: flex-start; flex-wrap: wrap;">
                    
                    <!-- Search Box -->
                    <div style="display: flex; flex-direction: column; gap: 0.25rem;">
                        <input 
                            type="text" 
                            name="search" 
                            placeholder="Cari.." 
                            value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>"
                            style="padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px; width: 200px;"
                        >
                        <small style="color: #666; font-size: 0.85rem;">Contoh: "admin, aktif" atau "siswa nonaktif"</small>
                    </div>

                    <!-- Date Range Filter -->
                    <div style="display: flex; flex-direction: column; gap: 0.25rem;">
                        <div style="display: flex; gap: 0.5rem; align-items: center;">
                            <label>Dari:</label>
                            <input 
                                type="date" 
                                name="start_date" 
                                value="<?= isset($_GET['start_date']) ? htmlspecialchars($_GET['start_date']) : '' ?>"
                                
                            >
                        </div>
                        <div>
                            <label>Sampai:</label>
                            <input 
                                type="date" 
                                name="end_date" 
                                value="<?= isset($_GET['end_date']) ? htmlspecialchars($_GET['end_date']) : '' ?>"
                            >
                        </div>
                    </div>

                    <!-- Month Filter -->
                    <div style="display: flex; flex-direction: column; gap: 0.25rem;">
                        <label style="font-weight: bold;">Pilih Bulan:</label>
                        <input 
                            type="month" 
                            name="month" 
                            value="<?= isset($_GET['month']) ? htmlspecialchars($_GET['month']) : '' ?>"
                            style="padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px;"
                        >
                    </div>
                    
                    <!-- Hidden fields untuk preserve existing parameters -->
                    <?php 
                        foreach ($_GET as $key => $value) {
                            if (!in_array($key, ['search', 'start_date', 'end_date', 'month'])) {
                                ?>
                                <input type="hidden" name="<?= htmlspecialchars($key) ?>" value="<?= htmlspecialchars($value) ?>">
                                <?php
                            }
                        }
                    ?>
                    
                    <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                        <button type="submit" class="btn-form" style="padding: 0.5rem 1rem; margin: 0;">Cari</button>
                        <?php if (isset($_GET['search']) || isset($_GET['start_date']) || isset($_GET['end_date']) || isset($_GET['month'])): ?>
                            <a href="a_anggota.php" class="btn-form" style="padding: 0.5rem 1rem; margin: 0; background-color: #999;">Reset</a>
                        <?php endif; ?>
                    </div>
                </form>
            </section>
        <section class="container" style="display: block;"> 
            
            <section class="flex" style="margin-bottom: 1rem; justify-content: flex-start;">
                <h4>Semua anggota</h4>
            </section>
            <div class="flex overflow-x">
                <table class="flex-grow">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th title="Foto Profil">Pfp</th>
                            <th>Username</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Waktu Gabung</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>

                    <?php 
                    $no= 1;
                    if (empty($get_all)) {
                        ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 2rem;">
                                Tidak ada data yang ditemukan
                            </td>
                        </tr>
                        <?php
                    } else {
                        foreach ($get_all as $result) { 
                    ?>
                        <tr>
                            <td> <?= $no++ ?></td>
                            <td><div class="profile-holder"><img src="../asset/img/pfp/<?= $result->pfp_path?>" alt="gambar"></div></td>
                            <td> <?= $result->username ?></td>
                            <td> <?= $result->role ?></td>
                            <td> <?= $result->status_akun ?></td>
                            <td> <?= date( "d F Y" , strtotime($result->waktu_buat)) ?></td>
                            <td style="display: flex; justify-content: center; gap: 5px;">
                                <a class="edit" href="a_anggota-detail.php?id=<?= $result->id_user?>">Detail akun</a>
                            </td>
                        </tr>
                    <?php } } ?>
                    </tbody>
                </table>
            </div>
        </section>

<!-- footer & closing -->
<?php
    include "../html/footer.php";
?>