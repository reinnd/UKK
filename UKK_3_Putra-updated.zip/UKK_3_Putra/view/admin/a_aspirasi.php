<?php
  include_once "../../controller/c_auth.php";

    use App\c_auth\guard;
    guard::soadmin();
    
  include_once "../../controller/c_aspirasi.php";
  $active_page = 'aspirasi';
  include "../html/header.php";
?>
  <title>Aspirasi</title>
</head>
<body>
  <?php 
    include "../html/navbar.php";
  ?>


    <section class="container">
            <form method="GET" id="searchForm" style="display: flex; gap: 1rem; align-items: flex-start; flex-wrap: wrap;">
                
                <!-- Search Box -->
                <div style="display: flex; flex-direction: column; gap: 0.25rem;">
                    <input 
                        type="text" 
                        name="search" 
                        placeholder="Cari judul/username/kategori/status.." 
                        value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>"
                        style="padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px; width: 200px;"
                    >
                    <small style="color: #666; font-size: 0.85rem;">Contoh: "menunggu, proses" atau "kategoriX"</small>
                </div>

                <!-- Date Range Filter -->
                <div style="display: flex; flex-direction: column; gap: 0.25rem;">
                    <div style="display: flex; gap: 0.5rem; align-items: center;">
                        <label>Dari:</label>
                        <input 
                            type="date" 
                            name="start_date" 
                            value="<?= isset($_GET['start_date']) ? htmlspecialchars($_GET['start_date']) : '' ?>"
                        >
                    </div>
                    <div>
                        <label>Sampai:</label>
                        <input 
                            type="date" 
                            name="end_date" 
                            value="<?= isset($_GET['end_date']) ? htmlspecialchars($_GET['end_date']) : '' ?>"
                        >
                    </div>
                </div>

                <!-- Month Filter -->
                <div style="display: flex; flex-direction: column; gap: 0.25rem;">
                    <label style="font-weight: bold;">Pilih Bulan:</label>
                    <input 
                        type="month" 
                        name="month" 
                        value="<?= isset($_GET['month']) ? htmlspecialchars($_GET['month']) : '' ?>"
                        style="padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px;"
                    >
                </div>
                
                <!-- Hidden fields untuk preserve existing parameters -->
                <?php 
                    foreach ($_GET as $key => $value) {
                        if (!in_array($key, ['search', 'start_date', 'end_date', 'month'])) {
                            ?>
                            <input type="hidden" name="<?= htmlspecialchars($key) ?>" value="<?= htmlspecialchars($value) ?>">
                            <?php
                        }
                    }
                ?>
                
                <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                    <button type="submit" class="btn-form" style="padding: 0.5rem 1rem; margin: 0;">Cari</button>
                    <?php if (isset($_GET['search']) || isset($_GET['start_date']) || isset($_GET['end_date']) || isset($_GET['month'])): ?>
                        <a href="a_aspirasi.php" class="btn-form" style="padding: 0.5rem 1rem; margin: 0; background-color: #999;">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </section>

  <div class="container">
      <h4>Semua Aspirasi</h4>
      
      <?php if (empty($data)): ?>
      <p style="text-align: center; padding: 2rem; color: #666;">Tidak ada data yang ditemukan</p>
      <?php else: ?>
      <div class="flex" style="overflow-x:scroll;">
        <table class="flex-grow">
          <thead>
            <tr>
              <th>No</th>
              <th>Topik</th>
              <th>Dari</th>
              <th>Kategori</th>
              <th>Isi</th>
              <th>Status</th>
              <th>Tanggal</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $no = 1;
            foreach ($data as $result){
            ?>
            <tr>
              <td class="table-number"><?= $no++ ?></td>
              <td><?= $result->judul ?></td>
              <td><?= $result->username ?></td>
              <td><?= $result->isi_kategori ?></td>
              <td><?= $result->isi_aspirasi ?></td>
              <?php 
                  $stats = $result->status;
                  if ($stats === 'menunggu') { ?>
                      <td><i class="menunggu-style"><?= $stats ?></i></td>
              <?php } else if ($stats === 'proses') { ?>
                  <td><i class="proses-style"><?= $stats ?></i></td>
              <?php } else if ($stats === 'selesai') { ?>
                  <td><i class="selesai-style"><?= $stats ?></i></td>
              <?php } else { ?>
                  <td><i class="error-style"><?= $stats ?></i></td>
              <?php } ?>
              <td><?= date( "j M Y" ,strtotime($result->waktu_upload)) ?></td>
              <?php 
                if($result->status == 'selesai') { ?>
                  <td><a class="edit" href="a_balas.php?id=<?= $result->id_aspirasi ?>">Lihat balasan</a></td>
              <?php } elseif($result->status == 'proses') { ?>
                  <td><a class="edit" href="a_balas.php?id=<?= $result->id_aspirasi ?>">Selesaikan</a></td>
              <?php } else { ?>
                  <td><a class="edit" href="a_balas.php?id=<?= $result->id_aspirasi ?>">Proses</a></td>
              <?php } ?>
            </tr>
            <?php 
              }
            ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  <?php
    include "../html/footer.php";
  ?>
</body>
</html>
  <?php
    include "../html/footer.php";
  ?>