<?php

    include_once "../../controller/c_auth.php";

    use App\c_auth\guard;
    guard::soadmin();
    
    include_once "../../controller/c_aspirasi.php";

        $db = new m_aspirasi();
        $total_data = $db->count_all();
        $total_data_status1 = $db->count_by_status("selesai");
        $total_data_status2 = $db->count_by_status("proses");
        $total_data_status3 = $db->count_by_status("menunggu");

        //ganination seting
        $limit = 5;
        $dash_aspirasi = $db->get_data($limit);
        $total_page = $db->get_total_page($limit);
    //head
    $active_page = 'dashboard';
    include "../html/header.php";
?>
    <title>Dashboard</title>
</head>
<body>
    <!-- header & navigation -->
<?php
    include "../html/navbar.php";
?>
<!-- main start here -->
            <section class="container grid grid-template-default">
                <div class="box dash selesai-aspirasi">
                    <p>Selesai</p>
                    <div><?= $total_data_status1->total_aspirasi ?></div>
                </div>
                <div class="box dash diproses-aspirasi">
                    <p>Diproses</p>
                    <div><?= $total_data_status2->total_aspirasi ?></div>
                </div>
                <div class="box dash menunggu-aspirasi">
                    <p>Menunggu</p>
                    <div><?= $total_data_status3->total_aspirasi ?></div>
                </div>
                <div class="box dash total-aspirasi">
                    <p>Total</p>
                    <div><?= $total_data->total_aspirasi ?></div>
                </div>
            </section>
            <section class="container">
                <h4 style="margin-bottom: 5px;">Terbaru</h4>
                <div class="flex ">
                    <table class="flex-grow">
                        <thead>
                            <th>no</th>
                            <th>topik</th>
                            <th>dari</th>
                            <th>balasan</th>
                            <th>status</th>
                        </thead>
                        <tbody>
                        <?php
                        if($total_data->total_aspirasi > 0){
                            $no = 1;
                            foreach ($dash_aspirasi as $result){
                            ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= $result->judul ?></td>
                                    <td><?= $result->username ?></td>
                                    <td><?= $result->isi_feedback ?></td>
                                    <?php 
                                        $stats = $result->status;
                                        if ($stats === 'menunggu') { ?>
                                            <td><i class="menunggu-style"><?= $stats ?></i></td>
                                    <?php } else if ($stats === 'proses') { ?>
                                        <td><i class="proses-style"><?= $stats ?></i></td>
                                    <?php } else if ($stats === 'selesai') { ?>
                                        <td><i class="selesai-style"><?= $stats ?></i></td>
                                    <?php } else { ?>
                                        <td><i class="error-style"><?= $stats ?></i></td>
                                    <?php } ?>
                                    </tr>
                            <?php 
                            }} else {
                            ?>
                                <tr>
                                    <td colspan="5">Belum ada aspirasi</td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <?php if($total_page > 0){ 
                    $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
                    if ($current_page < 1) $current_page = 1;
                    if ($current_page > $total_page) $current_page = $total_page;
                ?>
                    <ul class="pagination">
                        <li><a href="?page=<?= max(1, $current_page - 1) ?>" 
                               class="<?= ($current_page <= 1) ? 'disabled' : '' ?>">&laquo;</a></li>
                        <li><a href="?" class="<?= $current_page == 1 ? 'active' : '' ?>">1</a></li>
                        <?php 
                            for($i = 2; $i <= $total_page; $i++) {
                                $active = ($i == $current_page) ? 'active' : '';
                        ?>
                            <li><a href="?page=<?= $i ?>" class="<?= $active ?>"><?= $i ?></a></li>
                        <?php } ?>
                        <li><a href="?page=<?= min($total_page, $current_page + 1) ?>" 
                               class="<?= ($current_page >= $total_page) ? 'disabled' : '' ?>">&raquo;</a></li>
                    </ul>
                <?php } ?>
            </section>
<!-- footer & closing -->
<?php

    include "../html/footer.php";
?>