<?php
    include_once "../../controller/c_auth.php";

    use App\c_auth\guard;
    guard::soadmin();
    include_once "../../controller/c_extras.php";
    //head
    $active_page = 'amggota';
    include "../html/header.php";
?>
    <link rel="stylesheet" href="../asset/style/form.css?v=2">
    <script src="../asset/js/memberAdd.js?v=1"></script>
    <script src="../asset/js/allClass.js"></script>
    <title>Tambah Anggota</title>
    <style>
        .admin-only {
            display: none;
        }
        .admin-only.visible {
            display: block;
        }        .siswa-only {
            display: none;
        }
        .siswa-only.visible {
            display: block;
        }    </style>
</head>
<body>
    <!-- header & navigation -->
<?php
    include "../html/navbar.php";
?>
<!-- main start here -->
            <section class="container form-container">
                <form id="act_mod" action='' method="post">
                    <div class="flex">
                        <h4>Tambah Anggota</h4>
                        <div>
                            <a class="back" href="a_anggota.php">
                            <i class="fa-solid fa-arrow-turn-down fa-rotate-90"></i>
                            Kembali
                        </a>
                        </div>
                
                    </div>

                    <div class="form-group flex">
                        <label for="username">Username</label>
                        <input type="text" id="username" class="input-container" placeholder="" name="username" maxlength="50" class="" required>
                    </div>
                    <div class="form-group flex">
                        <label for="flname">Nama Lengkap</label>
                        <input type="text" id="flname" class="input-container" placeholder="" name="flname" maxlength="50" class="" required>
                    </div>
                    <div class="form-group flex">
                        <label for="password">Password</label>
                        <input type="password" id="password" class="input-container" minlength="8" name="password" required>
                    </div>
                    <div class="form-group flex">
                        <label for="role">Role</label>
                        <select id="role" name="role" class="input-container" required>
                            <option value="" disabled selected>Pilih Role</option>
                            <option value="admin">Admin</option>
                            <option value="siswa">Siswa</option>
                        </select>
                    </div>
                    <div class="siswa-only" id="siswa-fields">
                        <div class="form-group">
                            <label for="kelas">Kelas: </label>
                            <div class="flex">
                                <select name="kelas" id="subject" class="input-container">
                                    <option value="" disabled selected>Pilih Kelas</option>
                                </select>
                                <select name="jurusan" id="topic" class="input-container">
                                    <option value="" disabled selected>Pilih Jurusan</option>
                                </select>
                                <select name="subkelas" id="chapter" class="input-container">
                                    <option value="" disabled selected>Pilih Subkelas</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group flex">
                            <label for="nis">NIS</label>
                            <input type="text" class="input-container" id="nis" name="nis" disabled>
                        </div>
                    </div>

                    <div class="admin-only" id="admin-fields">
                        <div class="form-group flex">
                            <label for="bidang">Bidang: </label>
                            <select name="bidang" id="" class="input-container">
                                    <?php foreach ($bidang as $result) { ?>
                                        <option value="<?= $result ?>"><?= $result ?></option>
                                    <?php } ?>
                            </select>
                        </div>
                        <div class="form-group flex">
                            <label for="nip">NIP: </label>
                            <input type="text" name="nip" value="" maxlength="18" class="input-container">
                        </div>
                    </div>

                    <button type="submit" class="btn-form">BUAT</button>
                    
                </form>
            </section>
<!-- footer & closing -->
<?php
    include "../html/footer.php";
?>

