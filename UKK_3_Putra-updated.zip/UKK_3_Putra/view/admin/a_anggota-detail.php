<?php
    include_once "../../controller/c_auth.php";

    use App\c_auth\guard;
    guard::soadmin();

    include_once "../../model/m_user.php";
    $db = new m_admin();
    $db2 = new m_siswa();
    $data_user = $db->get_all_data_by_id($_GET['id']);

    if($data_user->role === 'admin'){
        $admin = $db->get_data_by_user_id($_GET['id']);
        $merged_data = (object)array_merge((array)$data_user, (array)$admin);
    } else {
        $siswa = $db2->get_data_by_user_id($_GET['id']);
        $merged_data = (object)array_merge((array)$data_user, (array)$siswa);
    }

    include_once "../../controller/c_extras.php";
    
    //head
    $active_page = 'amggota';
    include "../html/header.php";
?>
    <link rel="stylesheet" href="../asset/style/form.css?v=2">
    <script src="../asset/js/allClass.js"></script>
    <title>Detail Anggota</title>
    <style>
        .displayed{
            display: block;
        }
        .notdis{
            display: none;
        }
    </style>
</head>
<body>
    <!-- header & navigation -->
<?php
    include "../html/navbar.php";
?>
<!-- main start here -->
            <section class="container form-container">
                <div class="flex">
                    <h4>Detail Akun <?= $merged_data->username ?></h4>
                    <div>
                        <a class="back" href="a_anggota.php">
                        <i class="fa-solid fa-arrow-turn-down fa-rotate-90"></i>
                        Kembali
                    </a>
                    </div>
                </div>
                <div class="flex" style="justify-content: flex-start;">
                    <div class="profile-holder-medium">
                        <img src="../asset/img/pfp/<?= $merged_data->pfp_path ?>" alt="profil">
                    </div>
                    <div style="margin-left: 3em; margin-top: 2em;">
                        <p><?= $merged_data->username ?></p>
                        <p title="Nama Lengkap"><?= ucwords($merged_data->nama_lengkap) ?></p>
                        <p><?= ucfirst($merged_data->role) ?></p>
                        <div></div>
                        <?php if ($merged_data->role === 'admin') { ?>
                            <p>Bidang: <?= $merged_data->bidang ?></p>
                            <p>NIP: <?= $merged_data->nip ?></p>
                        <?php } else { ?>
                            <p>Kelas: <?= $merged_data->kelas ?></p>
                            <p>NIS: <?= $merged_data->nis ?></p>
                        <?php } ?>
                        <p>Status Akun: <?= ucfirst($merged_data->status_akun) ?></p>
                    </div>
                    
                </div>
                <div style="margin-top:1.5em; flex-direction: column;" class="flex">
                    <h4>Edit User</h4>
                    <a class="edit button-gap" onclick="barToggle()" href="#?edit=">Edit Data User</a>
                    <div class="notdis compack-form-group" id="data-bar" >
                        <form class="flex table-btn-container" action="../../controller/c_user.php?action=update&type=data&role=<?= $merged_data->role ?>" method="post">
                            <input type="hidden" name="id_user" value="<?= $merged_data->id_user ?>">
                            <div>
                                <label for="username">Username: </label>
                                <input type="text" name="username" value="<?= $merged_data->username ?>" maxlength="50" id="username">
                            </div>
                            <div>
                                <label for="flname">Nama Lengkap: </label>
                                <input type="text" name="flname" value="<?= $merged_data->nama_lengkap ?>" maxlength="50">
                            </div>
                           <?php if($merged_data->role === 'admin') { ?>
                             <div>
                                <label for="bidang">Bidang: </label>
                                <select name="bidang" id="">
                                        <?php foreach ($bidang as $result) { ?>
                                            <option value="<?= $result ?>"><?= $result ?></option>
                                        <?php } ?>
                                </select>
                            </div>
                            <div>
                                <label for="nip">NIP: </label>
                                <input type="text" name="nip" value="<?= $merged_data->nip ?>" maxlength="18">
                            </div>
                           <?php } else { ?>
                           <div>
                                <label for="bidang">Kelas: </label>
                                <select name="kelas" id="subject">
                                    <option value="" disabled selected>Pilih Kelas</option>
                                </select>
                                <select name="jurusan" id="topic">
                                    <option value="" disabled selected>Pilih Jurusan</option>
                                </select>
                                <select name="subkelas" id="chapter">
                                    <option value="" disabled selected>Pilih Subkelas</option>
                                </select>
                            </div>
                            <div>
                                <label for="nip">NIS: </label>
                                <input type="text" name="nip" value="<?= $merged_data->nis ?>" maxlength="18">
                            </div>
                           <?php } ?>
                           <button type="submit" class="compack-btn-form">Terapkan</button>
                        </form>
                    </div>
                    <a id="stat-btn" onclick="barToggle2()" class="edit button-gap" href="#?status=">Ubah Status Akun</a>
                    <div class="compack-form-group notdis" id="stat-bar" >
                        <form class="flex table-btn-container" action="../../controller/c_user.php?action=update&type=status" method="post">
                            <label for="status">Ubah Status Akun</label>
                            <input type="number" name="id_user" id="id_user" value="<?= $merged_data->id_user ?>" hidden>
                            <select name="status" id="status">
                                <option value="<?= $merged_data->status_akun ?>" selected><?= ucfirst($merged_data->status_akun) ?></option>
                                <?php if($merged_data->status_akun === 'aktif'){ ?>
                                    <option value="nonaktif">Nonaktif</option>
                                <?php } else {?>
                                    <option value="aktif">Aktif</option>
                                <?php } ?>
                            </select>
                            <button type="submit" class="compack-btn-form">Terapkan</button>
                        </form>
                    </div>
                    <a class="delete button-gap" href="../../controller/c_user.php?action=update&type=bann&id_user=<?= $merged_data->id_user ?>" onclick="return confirm('Yakin mau ban akun ini?')">BAN <?= strtoupper($merged_data->username) ?></a>
                </div>
            </section>

            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const statBar = document.getElementById('stat-bar');
                    const dataBar = document.getElementById('data-bar');

                    window.barToggle = function() {
                        console.log('Toggle data-bar');
                        dataBar.classList.toggle("displayed");
                        dataBar.classList.toggle("notdis");
                    };

                    window.barToggle2 = function() {
                        console.log('Toggle stat-bar');
                        statBar.classList.toggle("displayed");
                        statBar.classList.toggle("notdis");
                    };
                });
            </script>
<!-- footer & closing -->
<?php
    include "../html/footer.php";
?>

