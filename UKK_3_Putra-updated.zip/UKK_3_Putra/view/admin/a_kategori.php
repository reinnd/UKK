<?php
include_once "../../controller/c_auth.php";

use App\c_auth\guard;
guard::soadmin();

include_once "../../controller/c_kategori.php";
$kategori = new m_kategori();
$id_kategori_edit = isset($_GET['id_kategori']) ? $_GET['id_kategori'] : 'NULL';
$data_kategori = $kategori->get_data_by_id($id_kategori_edit);

$active_page = "kategori";
include "../html/header.php";
?>
<script src="../asset/js/errorHandler.js?v=1"></script>
<title>Semua Kategori</title>
</head>

<body>
    <?php
    include "../html/navbar.php";
    ?>
    <div class="">
        <section class="container">
            
            <div class="flex">
                <div>
                    <h4 style="text-align:center;">Tambah kategori baru</h4>
                    <form action="../../controller/c_kategori.php?action=add" method="post">
                        <div class="form-group grid">
                            <input type="number" name="id_kategori" hidden>

                            <input class="input-container" type="text" name="isi_kategori" placeholder="kategori baru.." maxlength="30">
                            <button class="edit" type="submit">kirim</button>
                        </div>
                        
                    </form>
                </div>
                <div style="margin-right:1em;">
                    <h4 style="text-align:center;">Edit kategori</h4>
                    <form action="../../controller/c_kategori.php?action=update" method="post">
                        <?php
                        if($data_kategori){
                        ?>
                        <div class="form-group grid">
                            <input type="number" name="id_kategori" value="<?= $data_kategori->id_kategori ?>" hidden>

                            <input class="input-container" type="text" name="isi_kategori" value="<?= $data_kategori->isi_kategori ?>"
                                placeholder="kategori baru..">
                            <button class="edit" type="submit">kirim</button>
                            <a class="delete" href="?">Batal</a>
                        </div>
                        <?php } else { ?>
                        <input class="input-container" type="text" name="isi_kategori" placeholder="Pilih kategori untuk diedit" disabled>
                        
                        <?php } ?>
                    </form>
                </div>
            </div>
        </section>

        <section class="container">
            <h4>Semua kategori</h4>
            <div class="overflow-x flex">
                <table class="flex-grow">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kategori</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($all_kategori as $result) {
                            ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $result->isi_kategori ?></td>
                                <td class="flex" style="justify-content:center; gap:1em;">
                                    <button class="edit"><a style="color:black;"
                                            href="?id_kategori=<?= $result->id_kategori ?>"><i
                                                class="fa-solid fa-pen-to-square"></i> Edit</a></button>
                                    <button class="delete"><a style="color:black;"
                                            href="../../controller/c_kategori.php?action=delete&id_kategori=<?= $result->id_kategori ?>"
                                            onclick="return confirm('Yakin hapus kategori ini?')"><i
                                                class="fa-solid fa-trash-can"></i> Hapus</a></button>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <?php
    include "../html/footer.php";
    ?>
</body>

</html>